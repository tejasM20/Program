import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error

df = pd.read_csv("uber.csv")

df = df.dropna(subset=["fare_amount", "passenger_count", "pickup_longitude",
                       "pickup_latitude", "dropoff_longitude", "dropoff_latitude"])
df = df[(df["fare_amount"] > 0) & (df["passenger_count"] > 0)]
q1, q3 = df["fare_amount"].quantile([0.25, 0.75])
iqr = q3 - q1
outliers = ~df["fare_amount"].between(q1 - 1.5 * iqr, q3 + 1.5 * iqr)
print("Fare outliers (IQR):", outliers.sum())
df = df.loc[~outliers]
X = df[['passenger_count', 'pickup_longitude',
        'pickup_latitude', 'dropoff_longitude',
        'dropoff_latitude']]
y = df['fare_amount']
print("Feature correlations with fare:\n", X.corrwith(y))

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42)

lr = LinearRegression()
lr.fit(X_train, y_train)
p1 = lr.predict(X_test)

rf = RandomForestRegressor(n_estimators=50, random_state=42)
rf.fit(X_train, y_train)
p2 = rf.predict(X_test)

print("Linear Regression R2:", round(r2_score(y_test,p1),3))
print("Linear Regression RMSE:", round(mean_squared_error(y_test,p1)**0.5,3))
print("Random Forest R2:", round(r2_score(y_test,p2),3))
print("Random Forest RMSE:", round(mean_squared_error(y_test,p2)**0.5,3))
