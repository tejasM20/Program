from pathlib import Path

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

numeric = ["Age", "Fare", "SibSp", "Parch"]
categorical = ["Pclass", "Sex", "Embarked"]
features = numeric + categorical
data = pd.read_csv("train.csv")
X, y = data[features], data["Survived"]
X_train, X_valid, y_train, y_valid = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
preprocess = ColumnTransformer([
    ("numeric", make_pipeline(SimpleImputer(strategy="median"), StandardScaler()), numeric),
    ("categorical", make_pipeline(SimpleImputer(strategy="most_frequent"),
                                  OneHotEncoder(handle_unknown="ignore")), categorical),
])
model = make_pipeline(preprocess, LogisticRegression(max_iter=1000))
model.fit(X_train, y_train)
predictions = model.predict(X_valid)
print(confusion_matrix(y_valid, predictions))
print(classification_report(y_valid, predictions, zero_division=0))

if Path("test.csv").is_file():
    test = pd.read_csv("test.csv")
    model.fit(X, y)
    pd.DataFrame({"PassengerId": test["PassengerId"],
                  "Survived": model.predict(test[features])}).to_csv("submission.csv", index=False)
    print("Created submission.csv")
