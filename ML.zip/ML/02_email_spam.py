import pandas as pd
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import Normalizer
from sklearn.svm import LinearSVC

df = pd.read_csv("emails.csv").dropna(subset=["Prediction"])
# The syllabus dataset already represents each email as word-count columns.
X = df.drop(columns=["Prediction", "Email No."], errors="ignore").fillna(0)
y = df["Prediction"].astype(int)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, stratify=y, random_state=42
)

models = {
    "K-Nearest Neighbors": KNeighborsClassifier(n_neighbors=min(5, len(X_train))),
    "Linear SVM": LinearSVC(random_state=42, max_iter=5000),
}
for name, classifier in models.items():
    model = make_pipeline(Normalizer(), classifier)
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    print("\n" + name)
    print("Confusion matrix [not spam, spam]:")
    print(confusion_matrix(y_test, predictions, labels=[0, 1]))
    print(classification_report(y_test, predictions, labels=[0, 1],
                                target_names=["Not spam", "Spam"], zero_division=0))
