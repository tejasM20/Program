import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix, accuracy_score
from sklearn.metrics import precision_score, recall_score

df = pd.read_csv("diabetes.csv")

X = df.drop("Outcome", axis=1)
y = df["Outcome"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

model = KNeighborsClassifier(n_neighbors=5)
model.fit(X_train, y_train)

p = model.predict(X_test)

print("Confusion Matrix:")
print(confusion_matrix(y_test,p))
print("Accuracy:", round(accuracy_score(y_test,p),3))
print("Error Rate:", round(1-accuracy_score(y_test,p),3))
print("Precision:", round(precision_score(y_test,p),3))
print("Recall:", round(recall_score(y_test,p),3))
