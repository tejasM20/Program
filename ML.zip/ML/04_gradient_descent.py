x = 2
lr = 0.1

for i in range(20):
    gradient = 2 * (x + 3)
    x = x - lr * gradient

print("Minimum x =", round(x,4))
print("Minimum y =", round((x+3)**2,4))
