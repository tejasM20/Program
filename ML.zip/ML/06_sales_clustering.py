import matplotlib.pyplot as plt
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

df = pd.read_csv("sales_data_sample.csv", encoding="latin1")
columns = ["QUANTITYORDERED", "PRICEEACH"]
df = df.dropna(subset=columns).copy()
if len(df) < 3:
    raise SystemExit("At least three complete rows are required.")

X = StandardScaler().fit_transform(df[columns])
ks = list(range(1, min(10, len(df), len(df[columns].drop_duplicates())) + 1))
if len(ks) < 3:
    raise SystemExit("At least three distinct feature rows are required.")
models = [KMeans(n_clusters=k, random_state=42, n_init=10).fit(X) for k in ks]
inertias = [model.inertia_ for model in models]

# Choose the elbow with the greatest drop below the line joining the endpoints.
span = inertias[0] - inertias[-1]
best_index = max(range(1, len(ks) - 1),
                 key=lambda i: inertias[0] - span * i / (len(ks) - 1) - inertias[i])
print("Suggested elbow k:", ks[best_index])
df["Cluster"] = models[best_index].labels_
print(df[columns + ["Cluster"]].head())

plt.plot(ks, inertias, marker="o")
plt.axvline(ks[best_index], linestyle="--")
plt.xlabel("Number of clusters")
plt.ylabel("Within-cluster sum of squares")
plt.tight_layout()
plt.savefig("sales_elbow.png")
